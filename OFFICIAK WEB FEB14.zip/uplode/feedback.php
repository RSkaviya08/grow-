<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize the input to avoid XSS
    $feedback = htmlspecialchars($_POST['feedback']); 

    // Email configuration
    $to = "growwakeofficial@gmail.com"; // Recipient's email address
    $subject = "Feedback Submission";
    $message = "New feedback submitted:\n\n" . $feedback;
    $headers = "From: growwakeofficial@gmail.com"; // Sender's email address

    // Send the email
    if (mail($to, $subject, $message, $headers)) {
        // Send SMS after email success (optional)
        sendSMSNotification();

        // Display success message
        echo "Feedback sent successfully!";
    } else {
        echo "Error sending feedback.";
    }
}

// Function to send SMS notification (using Twilio as an example)
function sendSMSNotification() {
    // Twilio credentials (replace with your actual credentials)
    $sid = 'your_twilio_sid';
    $token = 'your_twilio_token';
    $twilio_number = 'your_twilio_number';  // Twilio number
    $recipient_number = 'recipient_phone_number';  // Your phone number for SMS

    // The message you want to send
    $message = 'New feedback submitted on your website.';

    // Twilio API URL
    $url = 'https://api.twilio.com/2010-04-01/Accounts/' . $sid . '/Messages.json';

    // POST data to send SMS
    $data = array(
        'From' => $twilio_number,
        'To' => $recipient_number,
        'Body' => $message,
    );

    // Using cURL to send the request to Twilio API
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    curl_setopt($ch, CURLOPT_USERPWD, $sid . ':' . $token);

    // Execute cURL and capture the response
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);

    return $response;
}
?>
