// function

function vfun()
{
    var uname= document.forms["myform"]["uname"].value;
    var mail=document.forms["myform"]["mail"].value;
    var quali=document.forms["myform"]["quali"].value;
    var pass=document.forms["myform"]["pass"].value;
    var ph=document.forms["myform"]["ph"].value;

    if(mail == null || mail=="")
        {
            document.getElementById("errorbox").innerHTML="Enter the Email";
            return false;
        }
    if(uname == null || uname=="")
    {
        document.getElementById("errorbox").innerHTML="Enter the UserName";
        return false;
    }
    
    if(quali == null || quali=="")
        {
             document.getElementById("errorbox").innerHTML="Enter the Qualification";
              return false;
          }
 if(ph == null || ph=="")
        {
         document.getElementById("errorbox").innerHTML="Enter the Phone Number";
        return false;
         }
  
    if(pass == null || pass=="")
           {
                document.getElementById("errorbox").innerHTML="Enter the Password";
                 return false;
             }
  
    if(uname !='' && mail !='' && ph != '' && quali != '' && pass != '')
    {
        alert("Submitted Succesfully");
        window.location.href = "index.html";


    }
}

function vfun2()
{
    var uname2=  document.getElementById("Name").value;
    var mail2= document.getElementById("Enter Email").value;
    var phone= document.getElementById("phone").value;
    var job= document.getElementById("job").value;

    if(uname2 == null || uname2=="")
        {
            document.getElementById("erbox").innerHTML="Enter the Name";
            return false;
        }
    if(mail2 == null || mail2=="")
    {
        document.getElementById("erbox").innerHTML="Enter the Mail";
        return false;
    }
    
    if(phone == null || phone=="")
        {
             document.getElementById("erbox").innerHTML="Enter the PhoneNumber";
              return false;
          }
 if(job == null || job=="")
        {
         document.getElementById("erbox").innerHTML="Enter the Job Role";
        return false;
         }
  
    if(uname2 !='' && mail2 !='' && phone != '' && job != '' )
    {  
        document.getElementById("erbox").innerHTML="";
        alert("Message send succesfully");
        window.location.reload();
    } 
}